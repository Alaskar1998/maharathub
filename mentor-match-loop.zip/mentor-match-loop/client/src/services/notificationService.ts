// Simplified notification service using API instead of Supabase
// Notification types (simplified)
interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  type: string;
  actionUrl?: string;
  metadata?: any;
  createdAt: Date;
  chatId?: string;
  senderName?: string;
}

interface NotificationCounts {
  total: number;
  general: number;
  chat: number;
}

interface ChatNotification extends Notification {
  senderName: string;
}

interface NotificationService {
  getNotifications(userId: string, type?: 'general' | 'chat'): Promise<Notification[]>;
  markAsRead(notificationId: string): Promise<void>;
  markAllAsRead(userId: string): Promise<void>;
  createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification | null>;
  getNotificationCounts(userId: string): Promise<NotificationCounts>;
  getChatNotifications(userId: string): Promise<ChatNotification[]>;
}
import { apiService } from "./api";

// Simple logger for debugging
const logger = {
  debug: console.log,
  error: console.error,
};

class RealNotificationService implements NotificationService {
  async getNotifications(userId: string, type?: 'general' | 'chat'): Promise<Notification[]> {
    try {
      const notifications = await apiService.getNotifications(userId);
      
      if (Array.isArray(notifications)) {
        return notifications.map((notification: any) => ({
          id: notification.id,
          userId: notification.userId,
          title: notification.title,
          message: notification.message,
          isRead: notification.isRead,
          type: notification.type,
          actionUrl: notification.actionUrl,
          metadata: notification.metadata,
          createdAt: new Date(notification.createdAt),
          chatId: notification.chatId,
          senderName: notification.senderName,
        }));
      }
      
      return [];
    } catch (error) {
      logger.error('Error fetching notifications:', error);
      return [];
    }
  }

  async markAsRead(notificationId: string): Promise<void> {
    try {
      await apiService.markNotificationAsRead(notificationId);
    } catch (error) {
      logger.error('Error marking notification as read:', error);
    }
  }

  async markAllAsRead(userId: string): Promise<void> {
    try {
      // Get all notifications and mark them as read
      const notifications = await this.getNotifications(userId);
      await Promise.all(
        notifications.filter(n => !n.isRead).map(n => this.markAsRead(n.id))
      );
    } catch (error) {
      logger.error('Error marking all notifications as read:', error);
    }
  }

  async createNotification(notification: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification | null> {
    try {
      const created = await apiService.createNotification(notification);
      return created as Notification;
    } catch (error) {
      logger.error('Error creating notification:', error);
      return null;
    }
  }

  async getNotificationCounts(userId: string): Promise<NotificationCounts> {
    try {
      const notifications = await this.getNotifications(userId);
      const unreadNotifications = notifications.filter(n => !n.isRead);
      
      return {
        total: unreadNotifications.length,
        general: unreadNotifications.filter(n => !['new_message', 'new_chat'].includes(n.type)).length,
        chat: unreadNotifications.filter(n => ['new_message', 'new_chat'].includes(n.type)).length,
      };
    } catch (error) {
      logger.error('Error getting notification counts:', error);
      return { total: 0, general: 0, chat: 0 };
    }
  }

  async getChatNotifications(userId: string): Promise<ChatNotification[]> {
    try {
      const notifications = await this.getNotifications(userId, 'chat');
      return notifications.map(n => ({
        ...n,
        senderName: n.senderName || 'Unknown User',
      })) as ChatNotification[];
    } catch (error) {
      logger.error('Error getting chat notifications:', error);
      return [];
    }
  }

  async deleteNotification(notificationId: string): Promise<void> {
    // Implement if needed
  }
}

export const notificationService = new RealNotificationService();
export default notificationService;