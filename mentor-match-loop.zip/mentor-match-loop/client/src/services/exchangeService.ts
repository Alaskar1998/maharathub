// Simplified exchange service using API instead of Supabase
import { apiService } from "./api";

// Simple logger for debugging
const logger = {
  debug: console.log,
  error: console.error,
};

export interface ExchangeData {
  id: string;
  student_name: string;
  mentor_name: string;
  skill: string;
  status: string;
  rating?: number;
  created_at: string;
  updated_at: string;
}

export interface LatestExchange {
  id: string;
  student: string;
  mentor: string;
  skill: string;
  action: string;
  rating: number;
  avatar: string;
  mentorBadge: string;
  created_at: string;
}

export const getLatestExchanges = async (limit: number = 10, isArabic: boolean = false): Promise<LatestExchange[]> => {
  try {
    logger.debug('Fetching latest exchanges...');
    
    // For now, return empty array until we implement full exchange tracking
    return [];
  } catch (error) {
    logger.error('Error fetching latest exchanges:', error);
    return [];
  }
};

export const getExchangesByStatus = async (status: string): Promise<ExchangeData[]> => {
  try {
    // Return empty array for now
    return [];
  } catch (error) {
    logger.error('Error fetching exchanges by status:', error);
    return [];
  }
};

export const updateExchangeStatus = async (exchangeId: string, status: string): Promise<boolean> => {
  try {
    // Return true for now
    return true;
  } catch (error) {
    logger.error('Error updating exchange status:', error);
    return false;
  }
};

export const getExchangeStats = async (): Promise<any> => {
  try {
    return {
      total: 0,
      completed: 0,
      pending: 0,
      cancelled: 0
    };
  } catch (error) {
    logger.error('Error fetching exchange stats:', error);
    return {
      total: 0,
      completed: 0,
      pending: 0,
      cancelled: 0
    };
  }
};

// Additional exports needed by components
export const getExchangeCount = async (): Promise<number> => {
  return 0;
};

// Types are already exported as interfaces above