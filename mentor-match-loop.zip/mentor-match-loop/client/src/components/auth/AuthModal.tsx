/**
 * @file AuthModal.tsx  
 * @description Simplified authentication modal for the migration
 */

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthComplete?: () => void;
  initialMode?: 'signIn' | 'signUp';
}

function AuthModal({
  isOpen,
  onClose,
  onAuthComplete,
  initialMode = 'signIn',
}: AuthModalProps) {
  const [mode, setMode] = useState<'signIn' | 'signUp'>(initialMode);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
  });

  const { login, signup } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (mode === 'signIn') {
        const result = await login(formData.email, formData.password);
        if (result.error) {
          toast({
            title: 'Sign in failed',
            description: result.error,
            variant: 'destructive',
          });
          return;
        }
      } else {
        const result = await signup({
          email: formData.email,
          password: formData.password,
          name: formData.name,
        });
        if (result.error) {
          toast({
            title: 'Sign up failed',
            description: result.error,
            variant: 'destructive',
          });
          return;
        }
      }

      toast({
        title: mode === 'signIn' ? 'Welcome back!' : 'Account created!',
        description: mode === 'signIn' ? 'Successfully signed in.' : 'Welcome to Maharat Hub!',
      });

      if (onAuthComplete) {
        onAuthComplete();
      }
      onClose();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'An unexpected error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {mode === 'signIn' ? 'Sign In' : 'Sign Up'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              required
            />
          </div>

          {mode === 'signUp' && (
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? 'Loading...' : (mode === 'signIn' ? 'Sign In' : 'Sign Up')}
          </Button>
        </form>

        <div className="text-center">
          <button
            type="button"
            onClick={() => setMode(mode === 'signIn' ? 'signUp' : 'signIn')}
            className="text-sm text-blue-600 hover:underline"
          >
            {mode === 'signIn' 
              ? "Don't have an account? Sign up" 
              : 'Already have an account? Sign in'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Named export for compatibility
export { AuthModal };
export default AuthModal;