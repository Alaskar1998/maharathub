import { pgTable, text, serial, integer, boolean, uuid, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Profiles table (main user data)
export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey(),
  displayName: text("display_name"),
  email: text("email"),
  bio: text("bio"),
  gender: text("gender"),
  country: text("country"),
  age: integer("age"),
  avatarUrl: text("avatar_url"),
  phone: text("phone"),
  skillsToTeach: jsonb("skills_to_teach").default('[]'),
  skillsToLearn: text("skills_to_learn").array().default([]),
  willingToTeachWithoutReturn: boolean("willing_to_teach_without_return").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Chats table
export const chats = pgTable("chats", {
  id: uuid("id").primaryKey().defaultRandom(),
  user1Id: uuid("user1_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  user2Id: uuid("user2_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skill: text("skill").notNull(),
  status: text("status").notNull().default('active'),
  exchangeState: text("exchange_state").default('pending_start'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  chatId: uuid("chat_id").notNull().references(() => chats.id, { onDelete: "cascade" }),
  senderId: uuid("sender_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

// Invitations table
export const invitations = pgTable("invitations", {
  id: uuid("id").primaryKey().defaultRandom(),
  senderId: uuid("sender_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  recipientId: uuid("recipient_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skill: text("skill").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default('pending'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Learning requests table
export const learningRequests = pgTable("learning_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skill: text("skill").notNull(),
  level: text("level").notNull(),
  description: text("description").notNull(),
  country: text("country").notNull(),
  urgency: text("urgency").notNull(),
  responsesCount: integer("responses_count").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Learning responses table
export const learningResponses = pgTable("learning_responses", {
  id: uuid("id").primaryKey().defaultRandom(),
  learningRequestId: uuid("learning_request_id").notNull().references(() => learningRequests.id, { onDelete: "cascade" }),
  responderId: uuid("responder_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  message: text("message").notNull(),
  status: text("status").notNull().default('pending'),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Reviews table
export const reviews = pgTable("reviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  chatId: uuid("chat_id").notNull().references(() => chats.id, { onDelete: "cascade" }),
  reviewerId: uuid("reviewer_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  reviewedUserId: uuid("reviewed_user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skillRating: integer("skill_rating").notNull(),
  communicationRating: integer("communication_rating").notNull(),
  reviewText: text("review_text"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Exchange contracts table
export const exchangeContracts = pgTable("exchange_contracts", {
  id: uuid("id").primaryKey().defaultRandom(),
  chatId: uuid("chat_id").notNull().references(() => chats.id, { onDelete: "cascade" }),
  user1Id: uuid("user1_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  user2Id: uuid("user2_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  user1Skill: text("user1_skill"),
  user2Skill: text("user2_skill"),
  user1IsMentorship: boolean("user1_is_mentorship").default(false),
  user2IsMentorship: boolean("user2_is_mentorship").default(false),
  user1Agreed: boolean("user1_agreed").default(false),
  user2Agreed: boolean("user2_agreed").default(false),
  user1Finished: boolean("user1_finished").default(false),
  user2Finished: boolean("user2_finished").default(false),
  user1Reviewed: boolean("user1_reviewed").default(false),
  user2Reviewed: boolean("user2_reviewed").default(false),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  type: text("type").notNull(),
  actionUrl: text("action_url"),
  metadata: jsonb("metadata"),
  chatId: uuid("chat_id").references(() => chats.id, { onDelete: "cascade" }),
  senderId: uuid("sender_id").references(() => profiles.id, { onDelete: "cascade" }),
  senderName: text("sender_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Skills table - central repository of all skills
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  emoji: text("emoji"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  popularityCount: integer("popularity_count").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// User skills table - links users to skills they teach/want to learn
export const userSkills = pgTable("user_skills", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => profiles.id, { onDelete: "cascade" }),
  skillId: integer("skill_id").notNull().references(() => skills.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // 'teach' or 'learn'
  level: text("level").notNull(), // 'beginner', 'intermediate', 'advanced', 'expert'
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

// Legacy users table for backward compatibility
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Relations
export const profilesRelations = relations(profiles, ({ many }) => ({
  sentInvitations: many(invitations, { relationName: "sender" }),
  receivedInvitations: many(invitations, { relationName: "recipient" }),
  chats1: many(chats, { relationName: "user1" }),
  chats2: many(chats, { relationName: "user2" }),
  sentMessages: many(chatMessages),
  learningRequests: many(learningRequests),
  learningResponses: many(learningResponses),
  writtenReviews: many(reviews, { relationName: "reviewer" }),
  receivedReviews: many(reviews, { relationName: "reviewee" }),
  notifications: many(notifications),
  userSkills: many(userSkills),
}));

export const skillsRelations = relations(skills, ({ many }) => ({
  userSkills: many(userSkills),
}));

export const userSkillsRelations = relations(userSkills, ({ one }) => ({
  user: one(profiles, {
    fields: [userSkills.userId],
    references: [profiles.id],
  }),
  skill: one(skills, {
    fields: [userSkills.skillId],
    references: [skills.id],
  }),
}));

export const chatsRelations = relations(chats, ({ one, many }) => ({
  user1: one(profiles, {
    fields: [chats.user1Id],
    references: [profiles.id],
    relationName: "user1",
  }),
  user2: one(profiles, {
    fields: [chats.user2Id],
    references: [profiles.id],
    relationName: "user2",
  }),
  messages: many(chatMessages),
  contract: one(exchangeContracts),
  reviews: many(reviews),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  chat: one(chats, {
    fields: [chatMessages.chatId],
    references: [chats.id],
  }),
  sender: one(profiles, {
    fields: [chatMessages.senderId],
    references: [profiles.id],
  }),
}));

export const invitationsRelations = relations(invitations, ({ one }) => ({
  sender: one(profiles, {
    fields: [invitations.senderId],
    references: [profiles.id],
    relationName: "sender",
  }),
  recipient: one(profiles, {
    fields: [invitations.recipientId],
    references: [profiles.id],
    relationName: "recipient",
  }),
}));

// Schema types
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertProfileSchema = createInsertSchema(profiles);
export const insertChatSchema = createInsertSchema(chats);
export const insertChatMessageSchema = createInsertSchema(chatMessages);
export const insertInvitationSchema = createInsertSchema(invitations);
export const insertLearningRequestSchema = createInsertSchema(learningRequests);
export const insertLearningResponseSchema = createInsertSchema(learningResponses);
export const insertReviewSchema = createInsertSchema(reviews);
export const insertExchangeContractSchema = createInsertSchema(exchangeContracts);
export const insertNotificationSchema = createInsertSchema(notifications);
export const insertSkillSchema = createInsertSchema(skills);
export const insertUserSkillSchema = createInsertSchema(userSkills);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Chat = typeof chats.$inferSelect;
export type InsertChat = z.infer<typeof insertChatSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type Invitation = typeof invitations.$inferSelect;
export type InsertInvitation = z.infer<typeof insertInvitationSchema>;
export type LearningRequest = typeof learningRequests.$inferSelect;
export type InsertLearningRequest = z.infer<typeof insertLearningRequestSchema>;
export type LearningResponse = typeof learningResponses.$inferSelect;
export type InsertLearningResponse = z.infer<typeof insertLearningResponseSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type ExchangeContract = typeof exchangeContracts.$inferSelect;
export type InsertExchangeContract = z.infer<typeof insertExchangeContractSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type UserSkill = typeof userSkills.$inferSelect;
export type InsertUserSkill = z.infer<typeof insertUserSkillSchema>;
