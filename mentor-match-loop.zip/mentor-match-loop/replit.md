# replit.md

## Overview

This is a skill exchange platform called "Mentor Match" or "Maharat Hub" (in Arabic) that connects learners with mentors for knowledge sharing. The application allows users to find teachers for skills they want to learn and offer skills they can teach in return. It features a full-stack architecture with a React frontend, Express.js backend, PostgreSQL database with Drizzle ORM, and comprehensive user management including chat functionality, exchange tracking, and gamification elements.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite build system
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and full RTL support for Arabic
- **State Management**: TanStack Query for server state and React Context for local state
- **Internationalization**: React i18next with English and Arabic language support
- **Routing**: React Router v6 with lazy-loaded route components for performance
- **PWA Features**: Service worker, offline support, and web app manifest

### Backend Architecture  
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions
- **API Structure**: RESTful API with separate route handlers and storage layer
- **Development Setup**: Vite middleware for hot module replacement in development
- **Build Process**: ESBuild for production bundling with external package handling

### Database Schema
The application uses a comprehensive PostgreSQL schema with the following key tables:
- **profiles**: User data including skills, bio, contact info, and preferences
- **chats**: Chat sessions between users with exchange state tracking
- **chat_messages**: Individual messages within chat sessions
- **invitations**: Learning request invitations between users
- **learning_requests**: Public skill learning requests
- **learning_responses**: Responses to learning requests
- **reviews**: User ratings and feedback system
- **exchange_contracts**: Formal skill exchange agreements
- **notifications**: User notification system

### Authentication & Authorization
- **Authentication**: Email-based signup/signin with session management
- **User Profiles**: Comprehensive profile system with skills, location, and preferences
- **Role System**: Basic user roles with potential for admin functionality
- **Privacy Controls**: User visibility settings and data protection

### Key Features
- **Skill Exchange System**: Users can offer skills to teach and request skills to learn
- **Real-time Chat**: WebSocket-like chat functionality for user communication
- **Search & Discovery**: Advanced search with filters for finding mentors/learners
- **Review System**: Ratings and feedback for completed exchanges
- **Gamification**: Coin economy, badges, and achievement system
- **Multilingual Support**: Full English/Arabic localization with RTL layout
- **Responsive Design**: Mobile-first design with progressive web app capabilities

## External Dependencies

### Database & Infrastructure
- **Neon Database**: PostgreSQL hosting with serverless capabilities
- **Drizzle ORM**: Type-safe database operations with migration support

### Frontend Libraries
- **React Ecosystem**: React, React DOM, React Router for core functionality
- **UI Components**: Radix UI primitives for accessible component foundation
- **Styling**: Tailwind CSS with custom theming and RTL support
- **Forms**: React Hook Form with Zod validation
- **Date Handling**: date-fns for internationalized date formatting
- **Icons**: Lucide React for consistent iconography

### Backend Dependencies
- **Express.js**: Web framework with middleware support
- **Session Storage**: connect-pg-simple for PostgreSQL session persistence
- **Development Tools**: tsx for TypeScript execution, ESBuild for bundling

### Development & Build Tools
- **Vite**: Frontend build tool with HMR and plugin ecosystem
- **TypeScript**: Type safety across frontend and backend
- **PostCSS**: CSS processing with Tailwind and Autoprefixer
- **Path Aliases**: Configured for clean imports (@/ for client, @shared/ for shared code)

### Optional Integrations
- **TanStack Query**: Server state management with caching and synchronization
- **React i18next**: Internationalization with namespace support
- **Embla Carousel**: Touch-friendly carousel components
- **Service Worker**: PWA functionality with offline capabilities