import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateUUID } from "./utils";

// Extend Request type for user session
interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    displayName?: string;
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post('/api/auth/signup', async (req: Request, res: Response) => {
    try {
      const { email, displayName, password } = req.body;
      const id = generateUUID();
      
      // Check if user already exists
      const existingUser = await storage.getProfileByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists' });
      }
      
      const profile = await storage.createProfile({
        id,
        email,
        displayName: displayName || email.split('@')[0],
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      
      res.json({ user: profile });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create user' });
    }
  });
  
  app.post('/api/auth/signin', async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      const profile = await storage.getProfileByEmail(email);
      
      if (!profile) {
        return res.status(401).json({ error: 'User not found' });
      }
      
      res.json({ user: profile });
    } catch (error) {
      res.status(500).json({ error: 'Failed to sign in' });
    }
  });
  
  // Profile routes
  app.get('/api/profiles/:id', async (req: Request, res: Response) => {
    try {
      const profile = await storage.getProfile(req.params.id);
      if (!profile) {
        return res.status(404).json({ error: 'Profile not found' });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profile' });
    }
  });
  
  app.get('/api/profiles', async (req: Request, res: Response) => {
    try {
      const profiles = await storage.getAllProfiles();
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profiles' });
    }
  });
  
  app.patch('/api/profiles/:id', async (req: Request, res: Response) => {
    try {
      const profile = await storage.updateProfile(req.params.id, req.body);
      if (!profile) {
        return res.status(404).json({ error: 'Profile not found' });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });
  
  // Chat routes
  app.get('/api/chats', async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: 'userId is required' });
      }
      const chats = await storage.getUserChats(userId);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch chats' });
    }
  });
  
  app.post('/api/chats', async (req: Request, res: Response) => {
    try {
      const chat = await storage.createChat({
        id: generateUUID(),
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(chat);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create chat' });
    }
  });
  
  app.get('/api/chats/:id/messages', async (req: Request, res: Response) => {
    try {
      const messages = await storage.getChatMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });
  
  app.post('/api/chats/:id/messages', async (req: Request, res: Response) => {
    try {
      const message = await storage.createChatMessage({
        id: generateUUID(),
        chatId: req.params.id,
        ...req.body,
        createdAt: new Date(),
      });
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  
  // Invitation routes
  app.get('/api/invitations', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: 'userId is required' });
      }
      const invitations = await storage.getUserInvitations(userId);
      res.json(invitations);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch invitations' });
    }
  });
  
  app.post('/api/invitations', async (req: Request, res: Response) => {
    try {
      const invitation = await storage.createInvitation({
        id: generateUUID(),
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(invitation);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create invitation' });
    }
  });
  
  app.patch('/api/invitations/:id', async (req: Request, res: Response) => {
    try {
      const invitation = await storage.updateInvitation(req.params.id, req.body);
      if (!invitation) {
        return res.status(404).json({ error: 'Invitation not found' });
      }
      res.json(invitation);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update invitation' });
    }
  });
  
  // Learning request routes
  app.get('/api/learning-requests', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      let requests;
      if (userId) {
        requests = await storage.getUserLearningRequests(userId);
      } else {
        requests = await storage.getLearningRequests();
      }
      res.json(requests);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch learning requests' });
    }
  });
  
  app.post('/api/learning-requests', async (req: Request, res: Response) => {
    try {
      const request = await storage.createLearningRequest({
        id: generateUUID(),
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(request);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create learning request' });
    }
  });
  
  // Learning response routes
  app.get('/api/learning-requests/:id/responses', async (req: Request, res: Response) => {
    try {
      const responses = await storage.getLearningResponses(req.params.id);
      res.json(responses);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch responses' });
    }
  });
  
  app.post('/api/learning-requests/:id/responses', async (req: Request, res: Response) => {
    try {
      const response = await storage.createLearningResponse({
        id: generateUUID(),
        learningRequestId: req.params.id,
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(response);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create response' });
    }
  });
  
  // Review routes
  app.get('/api/reviews', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      const chatId = req.query.chatId as string;
      
      let reviews;
      if (chatId) {
        reviews = await storage.getChatReviews(chatId);
      } else if (userId) {
        reviews = await storage.getUserReviews(userId);
      } else {
        return res.status(400).json({ error: 'userId or chatId is required' });
      }
      
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch reviews' });
    }
  });
  
  app.post('/api/reviews', async (req: Request, res: Response) => {
    try {
      const review = await storage.createReview({
        id: generateUUID(),
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(review);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create review' });
    }
  });
  
  // Exchange contract routes
  app.get('/api/chats/:id/contract', async (req: Request, res: Response) => {
    try {
      const contract = await storage.getChatContract(req.params.id);
      res.json(contract);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch contract' });
    }
  });
  
  app.post('/api/chats/:id/contract', async (req: Request, res: Response) => {
    try {
      const contract = await storage.createExchangeContract({
        id: generateUUID(),
        chatId: req.params.id,
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(contract);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create contract' });
    }
  });
  
  app.patch('/api/contracts/:id', async (req: Request, res: Response) => {
    try {
      const contract = await storage.updateExchangeContract(req.params.id, req.body);
      if (!contract) {
        return res.status(404).json({ error: 'Contract not found' });
      }
      res.json(contract);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update contract' });
    }
  });
  
  // Notification routes
  app.get('/api/notifications', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: 'userId is required' });
      }
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch notifications' });
    }
  });
  
  app.post('/api/notifications', async (req: Request, res: Response) => {
    try {
      const notification = await storage.createNotification({
        id: generateUUID(),
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(notification);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create notification' });
    }
  });
  
  app.patch('/api/notifications/:id/read', async (req: Request, res: Response) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark notification as read' });
    }
  });
  
  const httpServer = createServer(app);

  return httpServer;
}
