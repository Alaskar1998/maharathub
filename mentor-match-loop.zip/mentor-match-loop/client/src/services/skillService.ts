// Simplified skill service using API instead of Supabase
// Import from local data files
// import { type Skill } from '@/data/skills';
type Skill = any; // Temporary type for now

export interface SkillValidationResult {
  isValid: boolean;
  normalizedName?: string;
  category?: string;
  error?: string;
}

export interface SkillDatabaseRecord {
  id: number;
  name: string;
  category: string;
  emoji?: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DatabaseSkill {
  name: string;
  count: number;
  category?: string;
}

class SkillService {
  validateSkill(skillName: string): Promise<SkillValidationResult> {
    if (!skillName || skillName.trim() === '') {
      return Promise.resolve({
        isValid: false,
        error: 'Skill name cannot be empty'
      });
    }

    const normalizedName = this.normalizeSkillName(skillName);
    
    return Promise.resolve({
      isValid: true,
      normalizedName,
      category: 'General'
    });
  }

  normalizeSkillName(skillName: string): string {
    return skillName.trim().replace(/\s+/g, ' ').toLowerCase()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  // Stub implementations for other methods
  async getSkillFromDatabase(): Promise<any> { return null; }
  async createSkillInDatabase(): Promise<any> { return null; }
  async getSkillStats(): Promise<DatabaseSkill[]> { return []; }
  async getAllSkills(): Promise<SkillDatabaseRecord[]> { return []; }
  async updateSkillStats(): Promise<void> { }
  async validateAndNormalizeSkills(): Promise<any[]> { return []; }
  async ensureSkillsExist(): Promise<void> { }
}

export const skillService = new SkillService();
export default skillService;

// Additional exports needed by components
export const getPopularSkillsFromDatabase = async (): Promise<DatabaseSkill[]> => {
  return [];
};

export const getCategoryEmoji = (category: string): string => {
  const emojiMap: Record<string, string> = {
    'Technology': '💻',
    'Languages': '🗣️',
    'Arts': '🎨',
    'Music': '🎵',
    'Sports': '⚽',
    'Cooking': '👨‍🍳',
    'Business': '💼',
    'General': '📚'
  };
  return emojiMap[category] || '📚';
};

// Types are already exported as interfaces above