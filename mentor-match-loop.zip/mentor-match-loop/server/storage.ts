import { db } from "./db";
import { 
  profiles,
  chats,
  chatMessages,
  invitations,
  learningRequests,
  learningResponses,
  reviews,
  exchangeContracts,
  notifications,
  type Profile,
  type InsertProfile,
  type Chat,
  type InsertChat,
  type ChatMessage,
  type InsertChatMessage,
  type Invitation,
  type InsertInvitation,
  type LearningRequest,
  type InsertLearningRequest,
  type LearningResponse,
  type InsertLearningResponse,
  type Review,
  type InsertReview,
  type ExchangeContract,
  type InsertExchangeContract,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { eq, desc, and, or } from "drizzle-orm";

export class DatabaseStorage {
  // Profile methods
  async getProfile(id: string): Promise<Profile | undefined> {
    const result = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
    return result[0];
  }

  async getProfileByEmail(email: string): Promise<Profile | undefined> {
    const result = await db.select().from(profiles).where(eq(profiles.email, email)).limit(1);
    return result[0];
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const result = await db.insert(profiles).values(profile).returning();
    return result[0];
  }

  async updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile | undefined> {
    const result = await db.update(profiles).set({
      ...updates,
      updatedAt: new Date(),
    }).where(eq(profiles.id, id)).returning();
    return result[0];
  }

  async getAllProfiles(): Promise<Profile[]> {
    return await db.select().from(profiles).orderBy(desc(profiles.createdAt));
  }

  // Chat methods
  async getChat(id: string): Promise<Chat | undefined> {
    const result = await db.select().from(chats).where(eq(chats.id, id)).limit(1);
    return result[0];
  }

  async getUserChats(userId: string): Promise<Chat[]> {
    return await db.select().from(chats)
      .where(or(eq(chats.user1Id, userId), eq(chats.user2Id, userId)))
      .orderBy(desc(chats.updatedAt));
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    const result = await db.insert(chats).values(chat).returning();
    return result[0];
  }

  async updateChat(id: string, updates: Partial<InsertChat>): Promise<Chat | undefined> {
    const result = await db.update(chats).set({
      ...updates,
      updatedAt: new Date(),
    }).where(eq(chats.id, id)).returning();
    return result[0];
  }

  // Chat message methods
  async getChatMessages(chatId: string): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages)
      .where(eq(chatMessages.chatId, chatId))
      .orderBy(chatMessages.createdAt);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(message).returning();
    return result[0];
  }

  async markMessagesAsRead(chatId: string, userId: string): Promise<void> {
    await db.update(chatMessages)
      .set({ isRead: true })
      .where(
        and(
          eq(chatMessages.chatId, chatId),
          eq(chatMessages.senderId, userId)
        )
      );
  }

  // Invitation methods
  async getUserInvitations(userId: string): Promise<Invitation[]> {
    return await db.select().from(invitations)
      .where(or(eq(invitations.senderId, userId), eq(invitations.recipientId, userId)))
      .orderBy(desc(invitations.createdAt));
  }

  async createInvitation(invitation: InsertInvitation): Promise<Invitation> {
    const result = await db.insert(invitations).values(invitation).returning();
    return result[0];
  }

  async updateInvitation(id: string, updates: Partial<InsertInvitation>): Promise<Invitation | undefined> {
    const result = await db.update(invitations).set({
      ...updates,
      updatedAt: new Date(),
    }).where(eq(invitations.id, id)).returning();
    return result[0];
  }

  // Learning request methods
  async getLearningRequests(): Promise<LearningRequest[]> {
    return await db.select().from(learningRequests)
      .orderBy(desc(learningRequests.createdAt));
  }

  async getUserLearningRequests(userId: string): Promise<LearningRequest[]> {
    return await db.select().from(learningRequests)
      .where(eq(learningRequests.userId, userId))
      .orderBy(desc(learningRequests.createdAt));
  }

  async createLearningRequest(request: InsertLearningRequest): Promise<LearningRequest> {
    const result = await db.insert(learningRequests).values(request).returning();
    return result[0];
  }

  // Learning response methods
  async getLearningResponses(requestId: string): Promise<LearningResponse[]> {
    return await db.select().from(learningResponses)
      .where(eq(learningResponses.learningRequestId, requestId))
      .orderBy(desc(learningResponses.createdAt));
  }

  async createLearningResponse(response: InsertLearningResponse): Promise<LearningResponse> {
    const result = await db.insert(learningResponses).values(response).returning();
    return result[0];
  }

  async updateLearningResponse(id: string, updates: Partial<InsertLearningResponse>): Promise<LearningResponse | undefined> {
    const result = await db.update(learningResponses).set({
      ...updates,
      updatedAt: new Date(),
    }).where(eq(learningResponses.id, id)).returning();
    return result[0];
  }

  // Review methods
  async getChatReviews(chatId: string): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(eq(reviews.chatId, chatId))
      .orderBy(desc(reviews.createdAt));
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(eq(reviews.reviewedUserId, userId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const result = await db.insert(reviews).values(review).returning();
    return result[0];
  }

  // Exchange contract methods
  async getChatContract(chatId: string): Promise<ExchangeContract | undefined> {
    const result = await db.select().from(exchangeContracts)
      .where(eq(exchangeContracts.chatId, chatId))
      .limit(1);
    return result[0];
  }

  async createExchangeContract(contract: InsertExchangeContract): Promise<ExchangeContract> {
    const result = await db.insert(exchangeContracts).values(contract).returning();
    return result[0];
  }

  async updateExchangeContract(id: string, updates: Partial<InsertExchangeContract>): Promise<ExchangeContract | undefined> {
    const result = await db.update(exchangeContracts).set({
      ...updates,
      updatedAt: new Date(),
    }).where(eq(exchangeContracts.id, id)).returning();
    return result[0];
  }

  // Notification methods
  async getUserNotifications(userId: string): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(notification).returning();
    return result[0];
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db.update(notifications)
      .set({ isRead: true, updatedAt: new Date() })
      .where(eq(notifications.id, id));
  }

  async markAllNotificationsAsRead(userId: string): Promise<void> {
    await db.update(notifications)
      .set({ isRead: true, updatedAt: new Date() })
      .where(eq(notifications.userId, userId));
  }
}

export const storage = new DatabaseStorage();
