// API service to replace Supabase calls
const API_BASE_URL = '/api';

class ApiService {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Unknown error' }));
      throw new Error(error.message || `HTTP ${response.status}`);
    }

    return response.json();
  }

  // Auth methods
  async signUp(email: string, displayName: string, password: string) {
    return this.request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, displayName, password }),
    });
  }

  async signIn(email: string, password: string) {
    return this.request('/auth/signin', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  // Profile methods
  async getProfile(id: string) {
    return this.request(`/profiles/${id}`);
  }

  async getAllProfiles() {
    return this.request('/profiles');
  }

  async updateProfile(id: string, updates: any) {
    return this.request(`/profiles/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  // Chat methods
  async getChats(userId: string) {
    return this.request(`/chats?userId=${userId}`);
  }

  async createChat(chat: any) {
    return this.request('/chats', {
      method: 'POST',
      body: JSON.stringify(chat),
    });
  }

  async getChatMessages(chatId: string) {
    return this.request(`/chats/${chatId}/messages`);
  }

  async sendMessage(chatId: string, message: any) {
    return this.request(`/chats/${chatId}/messages`, {
      method: 'POST',
      body: JSON.stringify(message),
    });
  }

  // Invitation methods
  async getInvitations(userId: string) {
    return this.request(`/invitations?userId=${userId}`);
  }

  async createInvitation(invitation: any) {
    return this.request('/invitations', {
      method: 'POST',
      body: JSON.stringify(invitation),
    });
  }

  async updateInvitation(id: string, updates: any) {
    return this.request(`/invitations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  // Learning request methods
  async getLearningRequests(userId?: string) {
    const query = userId ? `?userId=${userId}` : '';
    return this.request(`/learning-requests${query}`);
  }

  async createLearningRequest(request: any) {
    return this.request('/learning-requests', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async getLearningResponses(requestId: string) {
    return this.request(`/learning-requests/${requestId}/responses`);
  }

  async createLearningResponse(requestId: string, response: any) {
    return this.request(`/learning-requests/${requestId}/responses`, {
      method: 'POST',
      body: JSON.stringify(response),
    });
  }

  // Review methods
  async getReviews(userId?: string, chatId?: string) {
    const params = new URLSearchParams();
    if (userId) params.append('userId', userId);
    if (chatId) params.append('chatId', chatId);
    return this.request(`/reviews?${params.toString()}`);
  }

  async createReview(review: any) {
    return this.request('/reviews', {
      method: 'POST',
      body: JSON.stringify(review),
    });
  }

  // Exchange contract methods
  async getChatContract(chatId: string) {
    return this.request(`/chats/${chatId}/contract`);
  }

  async createExchangeContract(chatId: string, contract: any) {
    return this.request(`/chats/${chatId}/contract`, {
      method: 'POST',
      body: JSON.stringify(contract),
    });
  }

  async updateExchangeContract(contractId: string, updates: any) {
    return this.request(`/contracts/${contractId}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  // Notification methods
  async getNotifications(userId: string) {
    return this.request(`/notifications?userId=${userId}`);
  }

  async createNotification(notification: any) {
    return this.request('/notifications', {
      method: 'POST',
      body: JSON.stringify(notification),
    });
  }

  async markNotificationAsRead(notificationId: string) {
    return this.request(`/notifications/${notificationId}/read`, {
      method: 'PATCH',
    });
  }
}

export const apiService = new ApiService();