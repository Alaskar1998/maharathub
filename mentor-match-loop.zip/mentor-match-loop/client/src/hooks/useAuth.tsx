import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from 'react';
import { apiService } from '../services/api';

// Simple logger for debugging
const logger = {
  debug: console.log,
  error: console.error,
};

interface User {
  id: string;
  email: string;
  name: string;
  profilePicture?: string;
  bio?: string;
  country?: string;
  age?: number;
  age_range?: string;
  gender?: string;
  phone?: string;
  role?: string;
  skillsToTeach: Array<{
    name: string;
    level: string;
    description: string;
    category?: string;
  }>;
  skillsToLearn: string[];
  willingToTeachWithoutReturn: boolean;
  userType: 'free' | 'premium';
  remainingInvites: number;
  appCoins: number;
  phoneVerified: boolean;
  successfulExchanges: number;
  rating: number;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  signup: (userData: any) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Check for stored user session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUser(userData);
        setIsAuthenticated(true);
      } catch (error) {
        logger.error('Error parsing stored user data:', error);
        localStorage.removeItem('currentUser');
      }
    }
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      const response = await apiService.signIn(email, password);
      
      if (response && (response as any).user) {
        const profileData = (response as any).user;
        
        const userData: User = {
          id: profileData.id,
          email: profileData.email || email,
          name: profileData.displayName || profileData.display_name || '',
          profilePicture: profileData.avatarUrl || profileData.avatar_url || '',
          bio: profileData.bio || '',
          country: profileData.country || '',
          age: profileData.age,
          age_range: profileData.ageRange || profileData.age_range || '',
          gender: profileData.gender || '',
          phone: profileData.phone || '',
          role: profileData.role || 'user',
          skillsToTeach: profileData.skillsToTeach || profileData.skills_to_teach || [],
          skillsToLearn: profileData.skillsToLearn || profileData.skills_to_learn || [],
          willingToTeachWithoutReturn: profileData.willingToTeachWithoutReturn || profileData.willing_to_teach_without_return || false,
          userType: profileData.userType || profileData.user_type || 'free',
          remainingInvites: 3,
          appCoins: 50,
          phoneVerified: false,
          successfulExchanges: 0,
          rating: 0,
        };
        
        setUser(userData);
        setIsAuthenticated(true);
        localStorage.setItem('currentUser', JSON.stringify(userData));
        
        return {};
      }
      
      return { error: 'Login failed' };
    } catch (error: any) {
      logger.error('Login error:', error);
      return { error: error.message || 'An unexpected error occurred' };
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (userData: any) => {
    try {
      setIsLoading(true);
      const response = await apiService.signUp(userData.email, userData.name, userData.password);
      
      if (response && (response as any).user) {
        const profileData = (response as any).user;
        
        const newUser: User = {
          id: profileData.id,
          email: profileData.email || userData.email,
          name: profileData.displayName || profileData.display_name || userData.name,
          profilePicture: '',
          bio: '',
          country: '',
          age: undefined,
          age_range: '',
          gender: '',
          phone: '',
          role: 'user',
          skillsToTeach: [],
          skillsToLearn: [],
          willingToTeachWithoutReturn: false,
          userType: 'free',
          remainingInvites: 3,
          appCoins: 50,
          phoneVerified: false,
          successfulExchanges: 0,
          rating: 0,
        };
        
        setUser(newUser);
        setIsAuthenticated(true);
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        
        return {};
      }
      
      return { error: 'Signup failed' };
    } catch (error: any) {
      logger.error('Signup error:', error);
      return { error: error.message || 'An unexpected error occurred' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      logger.debug('Logout function called');
      
      // Clear local state
      setUser(null);
      setIsAuthenticated(false);
      localStorage.removeItem('currentUser');
      
      logger.debug('Logout completed, state cleared');
    } catch (error) {
      logger.error('Unexpected error during logout:', error);
      // Still clear state even if there's an error
      setUser(null);
      setIsAuthenticated(false);
      localStorage.removeItem('currentUser');
      throw error;
    }
  };

  const updateUser = async (updates: Partial<User>) => {
    if (user) {
      logger.debug('Updating user with:', updates);

      // Update local state
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));

      // Update database profile
      try {
        await apiService.updateProfile(user.id, {
          displayName: updatedUser.name,
          bio: updatedUser.bio,
          country: updatedUser.country,
          age: updatedUser.age,
          ageRange: updatedUser.age_range,
          gender: updatedUser.gender,
          phone: updatedUser.phone,
          avatarUrl: updatedUser.profilePicture,
          skillsToTeach: updatedUser.skillsToTeach,
          skillsToLearn: updatedUser.skillsToLearn,
          willingToTeachWithoutReturn: updatedUser.willingToTeachWithoutReturn,
        });
        
        logger.debug('Profile updated successfully in database');
      } catch (error) {
        logger.error('Profile update error:', error);
        throw error;
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        login,
        signup,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};