import { useQuery } from "@tanstack/react-query";
import { apiService } from "@/services/api";
import { logger } from '@/utils/logger';

// Simplified dashboard stats using mock data for now
const getRealDashboardStats = async () => {
  // For now, return mock data while the full API is being implemented
  const totalUsers = 150;
  const newUsersThisWeek = 12;
  const activeChats = 25;
  const totalReviews = 45;
  const averageRating = 4.7;
  
  return {
    totalUsers,
    newUsersThisWeek,
    activeChats,
    totalReviews,
    averageRating
  };
};

const getRealProfiles = async () => {
  try {
    const profiles = await apiService.getAllProfiles();
    return profiles || [];
  } catch (error) {
    logger.error('Error fetching profiles:', error);
    return [];
  }
};

const getRealCountryDistribution = async () => {
  // Return mock data for now
  return [
    { country: 'United States', count: 45 },
    { country: 'United Kingdom', count: 32 },
    { country: 'Canada', count: 28 },
    { country: 'Germany', count: 22 },
    { country: 'France', count: 18 }
  ];
};

const getRealGenderDistribution = async () => {
  // Return mock data for now
  return [
    { gender: 'Male', count: 82 },
    { gender: 'Female', count: 68 }
  ];
};

const getRealRecentProfiles = async () => {
  try {
    const profiles = await apiService.getAllProfiles();
    return (profiles || []).slice(0, 10);
  } catch (error) {
    logger.error('Error fetching recent profiles:', error);
    return [];
  }
};

const getRealRecentActivity = async () => {
  // Return mock activity data for now
  return [];
};

// Hook for dashboard statistics
export const useAdminDashboardStats = () => {
  return useQuery({
    queryKey: ['/admin/dashboard-stats'],
    queryFn: getRealDashboardStats,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

// Hook for user profiles data
export const useAdminProfiles = () => {
  return useQuery({
    queryKey: ['/admin/profiles'],
    queryFn: getRealProfiles,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
};

// Hook for country distribution data
export const useAdminCountryDistribution = () => {
  return useQuery({
    queryKey: ['/admin/country-distribution'],
    queryFn: getRealCountryDistribution,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
};

// Hook for gender distribution data
export const useAdminGenderDistribution = () => {
  return useQuery({
    queryKey: ['/admin/gender-distribution'],
    queryFn: getRealGenderDistribution,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
};

// Hook for recent profiles
export const useAdminRecentProfiles = () => {
  return useQuery({
    queryKey: ['/admin/recent-profiles'],
    queryFn: getRealRecentProfiles,
    staleTime: 1 * 60 * 1000, // 1 minute
  });
};

// Hook for recent activity
export const useAdminRecentActivity = () => {
  return useQuery({
    queryKey: ['/admin/recent-activity'],
    queryFn: getRealRecentActivity,
    staleTime: 1 * 60 * 1000, // 1 minute
  });
};

// Transform profiles to user format for admin users table
const transformProfileToUser = (profile: any) => ({
  id: profile.id,
  name: profile.displayName || profile.display_name || 'Unknown',
  email: profile.email || '',
  country: profile.country || 'Unknown',
  status: 'active', // Default status
  userType: 'free', // Default user type
  exchanges: 0, // Mock data
  rating: 0, // Mock data
  joinedDate: new Date(profile.createdAt || profile.created_at || Date.now()).toLocaleDateString()
});

// Hook for admin users (transformed profiles)
export const useAdminUsers = () => {
  return useQuery({
    queryKey: ['/admin/users'],
    queryFn: async () => {
      try {
        const profiles = await apiService.getAllProfiles();
        return (profiles || []).map(transformProfileToUser);
      } catch (error) {
        logger.error('Error fetching users for admin:', error);
        return [];
      }
    },
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
};